const express = require("express");
const router = express.Router();
const userController = require("../controllers/user.controller.js");

/**
 * @route POST /users
 * @description Create new User
 * @body {name, email, password, phoneNumber}
 * @access public
 */
router.post("/", userController.register);
module.exports = router;
